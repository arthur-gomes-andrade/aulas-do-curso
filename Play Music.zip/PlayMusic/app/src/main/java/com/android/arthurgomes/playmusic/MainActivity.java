package com.android.arthurgomes.playmusic;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.arthurgomes.playmusic.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private MediaPlayer mediaPlayer;
private ImageView pause, play, stop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());

        EdgeToEdge.enable(this);

        setContentView(R.layout.binding.getRoot());
        mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.global);
        binding.pause.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
            if (mediaPlayer.isPlaying()){
                mediaPlayer.pause();
            }
            }

        });

        binding.play.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
            if (mediaPlayer != null){
                mediaPlayer.play();

            }
        });

        binding.stop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
            if (mediaPlayer.isPlaying()){
                mediaPlayer.stop();
                mediaPlayer = MediaPlayer
            }
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}


