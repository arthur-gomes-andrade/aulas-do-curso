package com.example.etimpamiarthurgomeselucascamilosobrecarga;

public class Pessoa {
    private String nome;
    private int idade;

    private String endereco;

    Pessoa (String nome){
        this.nome = nome;
    }

    Pessoa (String nome, int idade){
        this.nome = nome;
        this.idade = idade;
    }

    void exibirDados(String nome){
        System.out.println(nome);
    }

    void exibirDados( int idade, String nome){
        System.out.println("Nome:" + nome + "idade" + idade);
    }

    void exibirDados( int idade, String nome, String endereco){
        System.out.println("Nome:" + nome + "idade" + idade + "endereco:" + endereco);
    }

}
